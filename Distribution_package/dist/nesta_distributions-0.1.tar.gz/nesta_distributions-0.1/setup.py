from setuptools import setup

setup(name='nesta_distributions',
      version='0.1',
      description='Binomial and Gaussian distributions',
      packages=['nesta_distributions'],
      author='Nesta Enow',
      author_email='nestaenow@gmail.com',
      zip_safe=False)
